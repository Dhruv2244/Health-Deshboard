import Settings from "@/components/settings"

export default function SettingsPage() {
  return (
    <main className="min-h-screen bg-background">
      <Settings />
    </main>
  )
}
